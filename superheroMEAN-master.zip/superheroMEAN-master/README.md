# superheroMEAN
Simple MEAN app to show the use of filestack
